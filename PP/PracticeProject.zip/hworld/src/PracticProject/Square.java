package PracticProject;

public class Square extends shape {
	
    int length;
	
	public Square(int length )
	{
		this.length = length;
		
	}
	public double calculateArea()
	{
		return length*length;
	}
	
	public void displayArea()
	{
		System.out.println( "the area of square is:" + calculateArea());
	}


}
