package PracticProject;

public class shape {

	public void displayArea() {
		System.out.println("The shape is not having any area calculation method");
	}
}
